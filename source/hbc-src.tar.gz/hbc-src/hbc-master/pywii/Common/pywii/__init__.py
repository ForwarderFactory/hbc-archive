#!/usr/bin/env python2

from wii import *
