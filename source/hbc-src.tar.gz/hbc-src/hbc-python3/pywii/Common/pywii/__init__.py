#!/usr/bin/env python3

from .wii import *
