const char *bootmii_version = "%VERSION%";
